Config callback registration fix

Files:
  rrclient/main.c
  rrserver/main.c
  librrprotocol/cfg.fwdsp.c

Changes:
- Both rrclient and rrserver call config_fwdsp_init() before cfg_load().
- rrserver no longer manually registers the individual callbacks.
- config_fwdsp_init() owns registration for [fwdsp] and [pipelines].
- Legacy [pipeline] singular is accepted as a temporary compatibility alias.
- Forward declarations were added because config_fwdsp_init() appears before the
  callback definitions in cfg.fwdsp.c.
