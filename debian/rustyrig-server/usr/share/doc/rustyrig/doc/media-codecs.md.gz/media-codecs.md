# Native audio codec selection

The GTK RX/TX pickers and the shared GTK/TUI commands use the codec list
negotiated with the server. The supplied configuration and built-in defaults
provide these mono codecs:

| ID | Format | Sample rate | Payload bitrate |
|---|---|---|---|
| `pc16` | Signed 16-bit PCM | 16 kHz | 256 kbit/s |
| `g722` | G.722 wideband ADPCM | 16 kHz | 64 kbit/s |
| `mu16` | G.711 mu-law at 16 kHz | 16 kHz | 128 kbit/s |
| `mu08` | G.711 mu-law | 8 kHz | 64 kbit/s |
| `opus` | Opus, 20 ms frames | 16 kHz input | 24 kbit/s CBR |
| `oggv` | Ogg/Vorbis | 16 kHz | Variable, quality 0.3 |
| `aacv` | AAC-LC in ADTS frames | 16 kHz | 32 kbit/s CBR |

Each format also has a tone variant, made by replacing the last character
of its ID with uppercase `T`:

| Normal | Tone |
|---|---|
| `pc16` | `pc1T` |
| `g722` | `g72T` |
| `mu16` | `mu1T` |
| `mu08` | `mu0T` |
| `opus` | `opuT` |
| `oggv` | `oggT` |
| `aacv` | `aacT` |

Tone variants retain the 600 Hz sine source on both client and server.
They use the same encoding, decoding and recording branches as their normal
counterparts, but have independent pipeline IDs. They are listed after normal
codecs so automatic negotiation does not prefer a test tone. Commands accept
any letter case and send the canonical negotiated ID, including uppercase `T`.

G.722 uses GStreamer's `avenc_g722` and `avdec_g722` from gst-libav.
Mu-law uses `mulawenc` and `mulawdec`. Both endpoints need the plugins
for the selected codec; negotiation lists configured codecs, not an inventory
of installed plugins. G.722 retains more audio bandwidth than `mu08` at the
same payload bitrate. `pc16` is the uncompressed fallback.

`aacv` uses GStreamer's `avenc_aac`, `aacparse` and `avdec_aac` from gst-libav.
It sends ADTS-framed AAC-LC access units so browser decoders can consume the
packets individually. AAC is a useful browser fallback when Opus is not
available, but its browser support is discovered at runtime.

`pc16` preserves 16-bit linear PCM samples. `mu16` uses 8-bit logarithmic
mu-law samples at the same 16 kHz sample rate: half the bandwidth, with
quantization loss. Neither name denotes the RF modulation mode.

For LTE, start with Opus at 24–32 kbit/s mono and 20 ms frames; use AAC-LC at
32 kbit/s when browser compatibility matters, or G.722 at 64 kbit/s as a
simpler native fallback. These are payload rates, excluding the
RustyRig, WebSocket, TCP/IP and cellular overhead. WebSocket/TCP still stalls
behind retransmitted packets; choosing a lower bitrate cannot eliminate LTE
delay variation. The supplied Opus setting uses generic audio mode to retain
tones and noisy radio audio as well as speech.

Ogg is a container. `oggv` specifically selects Vorbis in Ogg using `vorbisenc`,
`oggmux`, `oggdemux` and `vorbisdec`. It uses 20 ms maximum mux/page delay.
The manager caches initialization packets and replays them for late subscribers
and warm encoder reuse, before sending live pages. This does not change the
network media framing. Child IPC marks initialization packets with the high
bit of the four-byte length, so rebuild fwdsp and its manager together.

## Commands

These commands work in both native client views:

```text
/rxcodec
/txcodec LIST
/rxcodec g722
/txcodec mu16 #2
/rxcodec mu08 <channel-uuid>
/rxcodec oggv
/rxcodec opuT
/rxcodec NONE
```

With no arguments, or with `LIST`, the command lists negotiated codec choices
and the direction's subscribed or explicitly disabled audio channels. Channel
numbers match `/media LIST`; a bare number or `#number` may be used.

Setting a codec without a channel targets all subscribed audio channels in
that direction, including channels previously disabled with `NONE`. An optional
UUID or channel number targets one channel. Use `/media SUBSCRIBE` to select
other available channels first. Codec names are case-insensitive.

Tab completion works in GTK and TUI, including immediately after a space.
The first codec argument offers negotiated codecs, `LIST` and `NONE`; the
second offers eligible channel UUIDs and list numbers for that direction.
`/media` completes its subcommands and channel references. `/msg`, `/notice`,
`/whois`, `/kick`, `/mute` and `/unmute` complete user names in the recipient
position. `/quota` completes subcommands and user arguments, but not numeric
quota values. `/server`, `/help`, `/syslog`, `/webcam` and `/quit` also offer
appropriate parameter choices. Completion respects the cursor position.

`NONE` unsubscribes the affected audio channels and releases their local audio
pipeline. Decoders stop immediately; unused encoders pause and retain the
existing `fwdsp.hangtime` lifetime. `NONE` is local subscription intent, not a
codec sent to the server. Selecting a codec again re-subscribes disabled
channels after the server confirms that codec. A direction disabled with
`NONE` stays off through channel announcements until re-enabled or disconnected.

The GTK pickers apply to all subscribed channels in their direction. The native
audio bridge still has one local pipeline per direction; the displayed codec
prefers a subscribed channel on the active VFO. These controls do not add
simultaneous decoding or mixing of multiple independent RX streams.

## Pipeline configuration

The `[pipelines]` sections in `config/rrclient.cfg` and `config/rrserver.cfg`
contain `<codec>.rx` and `<codec>.tx` entries (internally stored as
`pipeline:<codec>.rx` and `pipeline:<codec>.tx`). Shared built-in
defaults live in `fwdsp/default-pipelines.h`, used by the client, server and
fwdsp. Keep those defaults and the supplied configurations synchronized.
`codecs.allowed` controls advertisement; client `audio.prefer-codecs` controls
preference. Restart after editing configuration.

The client's normal TX pipelines use `pulsesrc` with the default local sound
input, followed by conversion/resampling to the codec's mono sample format.
To choose a particular input, set `device=<source-name>` on `pulsesrc` in the
client pipelines. RX pipelines still play through the configured sound output.

The server's normal encoding pipelines use pink noise at source amplitude
0.15 for testing. Replace that source with station capture when connecting the
radio audio. Server `.tx` means encoding audio for client reception, not RF TX.
The shared built-in defaults select the same sources as the supplied config
files. The manager passes its resolved pipeline to fwdsp with `-p` so parent
defaults are respected even when the config file omits pipeline entries.
Each pipeline keeps its raw S16LE `record-sink` branch for FLAC recording;
encoded transport packets remain length-framed.

Headless validation: `bash fwdsp/tests/test_codec_roundtrip.sh` checks all twelve
IDs in both configurations and each application's built-in defaults, including fragmented
and coalesced transport writes. `bash rrclient/tests/test_codec_commands.sh`
checks command selection, channel targeting, NONE and re-enabling.
`bash fwdsp/tests/test_switching.sh` exercises repeated switches with real
subprocesses, paused encoder reuse, subscriber-driven resume and child-exit
cleanup. It also checks that buffered packets from retired codecs cannot be
forwarded after a switch, and decodes Ogg following reuse and late joins.
It also checks that a parent-selected pipeline overrides child defaults/config.
Roundtrip tests replace client sound capture with a finite test source; actual
sound-card capture needs a running audio server and is not covered headlessly.
`python3 fwdsp/tests/opus_continuity.py` checks packet/sample retention from
normal 1024-sample capture buffers; a nonzero-audio check alone misses blips.
The worker drains queued samples without a per-packet delay, and encoded
appsinks use backpressure rather than dropping codec packets or stream headers.
`bash rrclient/tests/test_completion.sh` and
`node www/tests/web_completion.js` check parameter completion.
These checks do not establish that live Opus playback works on a particular
sound device.
